## Auteur : Congio Jorane
## Date : 3 octobre 2016
## Titre : Concaténer 3 listes en alternant
## Résumé : Écrire un programme qui concatène 3 listes en alternant 
## leurs éléments puis affiche la liste concaténée


## On définit nos 3 listes		
L1 = [ "homer" ,  "bart" ,  "marge" ,  "liza" ]
L2 = [ 1 , 2 , 3 , 5 , 8 , 13 , 21 , 44 ]
L3 = [ 1.0 , 1.11 , 1.222 , 1.3333 , 1.44444 , 1.555555 ]

## Liste finale, qui contient la concaténation
list_finale = list()

## On déclare un indice puis on boucle
## dans la plus grande liste entre les 3

indice = 0

while indice < max(len(L1), len(L2), len(L3)):
	if indice < len(L1):
		list_finale.append(L1[indice])
	if indice < len(L2):
		list_finale.append(L2[indice])
	if indice < len(L3):
		list_finale.append(L3[indice])
	
	indice += 1
	
print(list_finale)
