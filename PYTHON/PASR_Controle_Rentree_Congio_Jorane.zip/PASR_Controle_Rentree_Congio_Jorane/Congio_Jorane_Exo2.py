## Auteur : Congio Jorane
## Date : 3 octobre 2016
## Titre : Afficher l'alphabet bizarrement
## Résumé : On demande à l'utilisateur s'il veut afficher l'alphabet
## en minuscule ou majuscule et un entier N compris entre 3 et 5.
## On affichera ensuite l'alphabet à partir de la première lettre
## mais uniquement une lettre sur N

import string ## Pour éviter d'avoir à entrer l'alphabet manuellement

def get_alphabet(casse, ecart_lettre):
	"""
	Retourne l'alphabet en tenant compte de la casse et des lettres d'écart
	Entrées : 
		casse : m ou M pour minuscule ou majuscule
		ecart_lettre : le nombre de lettres à laisser entre chaque print, doit être compris entre 3 et 5
	Sorties :
		a_afficher : la liste avec les lettres qui nous intéressent
	Exemple d'appel :
		li = affiche_alphabet("m", 2)
	"""
	
	## On déclare une liste qui contient l'alphabet en minuscules ou majuscules suivant m
	alphabet = list()
	if casse == "m":
		alphabet = list(string.ascii_lowercase)
	else:
		alphabet = list(string.ascii_uppercase)	

	## On déclare un compteur pour afficher une lettre sur ecart_lettre
	compteur_lettre = 0
	
	## On déclare une nouvelle liste pour contenir les lettres
	a_afficher = list()
	
	## Le premier indice sera toujours la première lettre de l'alphabet
	a_afficher.append(alphabet[0])
	
	## On boucle dans la liste alphabet et on ne garde qu'une lettre sur ecart_lettre
	for value in alphabet:
		if compteur_lettre == ecart_lettre:
			a_afficher.append(value)
			compteur_lettre = 0
		compteur_lettre += 1
		
	return a_afficher
		

#########################
## PROGRAMME PRINCIPAL ##
#########################
	
## On demande à l'utilisateur s'il veut l'alphabet en minuscule ou majuscule
casse = str(input("Majuscule ou minuscule M/m : "))

## Gestion d'erreur : demander tant qu'il n'a pas rentré 'm' ou 'M'
while True:
	if casse == "m" or casse == "M":
		break
	casse = str(input("On attend M ou m\n"))

## On demande l'écart à l'utilisateur	
ecart_lettre = int(input("Une lettre sur combien (entre 3 et 5) : "))

## Gestion d'erreur : demander tant qu'il n'a pas rentré en entier entre 3 et 5
while True:
	if ecart_lettre >= 3 and ecart_lettre <= 5:
		break
	ecart_lettre = int(input("On attend un écart entre 3 et 5\n"))

## On récupère la liste générée par la fonction		
a_afficher = get_alphabet(casse, ecart_lettre)

## On l'affiche selon le format demadandé par l'énoncé :
print(''.join(a_afficher))
