## Auteur : Congio Jorane
## Date : 3 octobre 2016
## Titre : Afficher en triangle
## Résumé : Créer un programme qui attend un nombre N compris 
## entre 4 et 10, un caractère C et qui affiche un triangle rectangle
## creux de N lignes à l'aide du caractère C 


def triangle(nb_lignes, car_dess):
	"""
	Affiche le triange creux
	Entrées :
		nb_lignes : le nombre de ligne du triange
		car_dess : le caractère affiché pour le triange
	Exemple d'appel :
		triange(5, "p")
	"""
	
	## On commance par afficher une seule fois le caractère
	print(car_dess)
	
	## On déclare un compteur pour pouvoir multiplier par un entier
	i = 0
	
	## On utilise une boucle while pour afficher le triangle
	while i < nb_lignes:
		## Si on est pas à la dernière ligne d'affichage
		if i < nb_lignes - 1:
			print(car_dess + " " * i + car_dess)
		## Si on est à la dernière ligne, on ne doit pas afficher d'espaces
		else:
			print(car_dess * (i + 2))
		i += 1 
		
#########################
## PROGRAMME PRINCIPAL ##
#########################

## On demande le nombre de lignes à l'utilisateur	
nb_lignes = int(input("Nombre de lignes (entre 4 et 10 ) : "))

## Gestion d'erreur : demander tant qu'il n'a pas rentré en entier entre 4 et 10
while True:
	if ecart_lettre >= 4 and ecart_lettre <= 10:
		break
	ecart_lettre = int(input("On attend un écart entre 4 et 10\n"))

car_dess = str(input("Caractère du dessin : "))
triangle(nb_lignes, car_dess)
